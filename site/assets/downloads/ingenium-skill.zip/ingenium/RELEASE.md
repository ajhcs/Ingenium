# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.4
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: f33b788c7c54da5d1c0faf6cf332c8a2b0b10c650210e6ae63e20cf4583e1b5d
buildId: 897d06f517b2e4f18f619a4c2175a7c96666abeb55d42765ded5d447ae06f972
artifactFlavor: guidance
prepared: False
development: True
