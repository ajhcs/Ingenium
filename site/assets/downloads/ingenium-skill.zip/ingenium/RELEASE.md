# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.2
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 25e2dc6fa8c88287d88d3772623b48356fd40faa7276c3f7e81522bd0f4dbbfc
buildId: 9eaf83776c14140e7f944f0f2778624e4309f3420006f11c9cdac20034881e5e
artifactFlavor: guidance
prepared: False
development: True
