# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.3
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 7da914f9b08118b53899c1214d589ce1725e74a819dec0ce8294b49ac9f7b92a
buildId: 627c99a8a64b4e44341ff585ad72dcb97c8f9fb6aba3fc481d018477a8efdef6
artifactFlavor: guidance
prepared: False
development: True
