# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.4
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 46f4bbaeac70f4ac8495c474997860bd9e4f78fc0d96b1ef5fd1da8ef20aa152
buildId: 446e1ff757b5c66d9a8ef954782f2a7d2821d0243fd3114e0cc9432b6e2c0ca3
artifactFlavor: guidance
prepared: False
development: True
