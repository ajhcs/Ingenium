# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.3
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 54cb3c511419202a8f6b58ff872067dd44ba2f5b97a1d465a9cafe3bfb9f1701
buildId: cee719d0f43245b8202752c47a7258c22fdd425cb5eef0114070a895594b3445
artifactFlavor: guidance
prepared: False
development: True
