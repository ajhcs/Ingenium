# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.3
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 46f4bbaeac70f4ac8495c474997860bd9e4f78fc0d96b1ef5fd1da8ef20aa152
buildId: a318e442bb93665268da067ecb494c2d6af8b756e1a00b60efd72aa6686f33ed
artifactFlavor: guidance
prepared: False
development: True
