# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.1
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 8db490be26da5ab0435754f7689d9060b859ae3cb9561d48fcfa41fe877de263
buildId: 28d03d4c6c80699b644b71fbb73fbcdc86c558a511de1d50f1ec769dafb82b0c
artifactFlavor: guidance
prepared: False
development: True
