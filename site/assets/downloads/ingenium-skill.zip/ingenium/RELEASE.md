# Release identity

schema: ingenium-guidance-source/1
version: 0.2.0-alpha.3
sourceRevision: not-stamped
sourceTree: not-stamped
sourceContentSHA256: 97ba073c84cff157ac0c3a20039a771ad59b581d92ce753f6475a59a5211bebf
buildId: 8716534a6edb464b4ce6b9a521bb9d6609121cd9f613e8d80fe0a8dbea1fa1cc
artifactFlavor: guidance
prepared: False
development: True
