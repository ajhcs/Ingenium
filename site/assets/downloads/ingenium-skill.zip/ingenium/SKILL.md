---
name: ingenium
description: Explore creative direction, refine editable design studies, or select and adapt design resources. Use for consequential visual choices or an explicit Ingenium request.
---

Create, compare, revise, review, or continue from an ordinary request. For a small task, start with the useful result; no form, record, or project store is required. Add structured continuity only when it helps the work.

Develop the person's intended design. Follow their scope and existing choices; use only the guidance and resources that help the current task. A question, text comparison, visual fragment or finished artifact can each be a sufficient result.

Start with the next consequential uncertainty. Use existing context and reasonable, revisable assumptions; ask when an answer would materially change the work. Invite reactions through a small discriminating probe. “Too corporate” might concern type, language or composition: keep the interpretation tentative. A preference expressed about one comparison stays scoped to that comparison; do not invent taste scores.

When the person wants to discover the look together, work broad to narrow through concrete visual probes with their content, letting them react without needing design vocabulary. A palette comparison can use swatches and a small applied sample; a type or shape comparison can reuse the same diagram. Hold settled choices and other dimensions steady so their reaction has a clear subject. Make enough to learn from, then pause before committing a consequential preference that still needs their input. Colors, type, shapes and style are possible starting points, not a checklist or fixed order. Preserve the pace of a narrow edit or an explicitly autonomous request.

When comparing overall directions, vary their organizing ideas—hierarchy, relationships, experience or material language—not only their colors. For a settled edit, preserve the chosen direction. Keep expressed facts, observations, interpretations and scoped decisions distinct; explicitly identify a choice being reopened. Preserve authoritative engineering meaning, units, thresholds and obligations.

Match rigor to the intended use and the user's requested depth: a quick study, measured refinement or deeper delivery review. Adapt as feedback arrives. Use representative content and editable sources; preserve originals and make edits/exports separate. Build only the requested artifact types. Honor withheld references and templates; do not consult worked examples or full-design libraries to reconstruct a direction the user asked to develop independently.

For consequential interaction choices, use a small connected low-fidelity wireframe as iterative definition before polish or implementation. Inspect relevant actual UI precedents, expose the choices and recovery behavior, and reconcile review findings with requirements and model/data contracts where applicable. Preserve the user’s feedback gate before expanding; neither a fixed layout nor one screen per step is implied. Read [Connected wireframes](references/interaction-sketches.md) when this applies.

Render or preview the relevant result, inspect it at its intended size or interaction state, fix observed problems, and recheck the affected parts. Before reporting a file as delivered, verify its exact path exists and is nonempty, and open or parse it as appropriate. Confirm any export succeeded; stale files and later successful commands do not establish that. Build delivery lists from verified outputs and mark failed or omitted exports unavailable. Retain concise evidence of what changed. Stop when the requested outcome and relevant checks are satisfied; a new defect or unresolved claim can justify more work. Report an unavailable renderer or unsupported operation precisely while continuing useful source/text work. Numeric checks and model critique do not establish taste, user acceptance, complete accessibility or engineering adequacy.

For responsive web work, inspect actual narrow and enlarged-text renderings. Preserve useful text width: reduce compounded gutters and oversized headings before ordinary words fragment; wrap exceptional long tokens without shrinking the requested text. Check content and keyboard use in the affected state. No horizontal overflow alone does not establish readable reflow.

Read a reference only when its task applies:

For a small resource task—CSE connector, document fragment, palette, texture, font or icon—start with [Task resources](references/task-resources.md): bounded search, exact selection and retained current editable state.

| Current need | Reference |
| --- | --- |
| Find or adapt fonts, symbols, colors, surfaces or UI parts | [Resource routes](references/resource-libraries.md), then the selected route only |
| Develop hierarchy, spacing, type roles or useful guides | [Measured composition](references/composition.md) |
| Vary a theme, locale or direction while preserving meaning | [Presentation contexts](references/presentation-context.md) |
| Choose a diagram representation for relationships, time, state or responsibility | [Diagram meaning](references/diagram-meaning.md) |
| Controlled study with worked sources withheld | [Conceptual composition only](references/composition-concepts.md); read this file directly instead of loading or slicing the worked reference |
| Discover local helpers or export SVG to PNG | [Capabilities](references/capabilities.md) or [SVG](references/svg.md) |
| Measure layout, contrast or owned local browser states | [Scoped checks](references/checks.md) |
| Create an original font or perform supported vector operations | [Font/vector tools](references/fonts.md) |
| Interpret research evidence or permitted design precedents | [Design evidence](references/design-evidence.md) |
| Check generated media, converted exports or motion output | [Media and delivery context](references/delivery-context.md) |
| Persist a machine-readable decision record | [Record contract](references/record-contract.md) |
| Define or review consequential interactions through connected wireframes | [Connected wireframes](references/interaction-sketches.md) |
| Choose a wireframe, wireflow, state sequence, desktop study, empty/error study, collage, palette family or type specimen | [Design methods](references/design-methods.md) |
| Make consequential physical or formal engineering claims | [Domain boundaries](references/domains.md) |

Use a short reusable specification when it helps continuity; ordinary prose often suffices. Keep process notes in supporting records unless the artifact's audience needs them. Deliver the useful result, the checks actually performed and any remaining consequential uncertainty.

[Release or source identity](RELEASE.md).
